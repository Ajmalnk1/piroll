<?php
/**
 * Posts list
 *
 * @package Piroll
 */

$class = have_posts() ? 'nk-isotope' : '';

$class .= ' nk-isotope-3-cols nk-blog-isotope nk-isotope-gap nk-load-more-container';

echo '<div class="nk-gap-4"></div>';

?>
<div class="<?php echo esc_attr( $class ); ?>">
    <?php
    if ( have_posts() ) :
        /* Start the Loop */
        while ( have_posts() ) :
            the_post();
            get_template_part( '/template-parts/content-archive-post-masonry' );
        endwhile;
        else :
            get_template_part( 'template-parts/content', 'none' );
    endif;
        ?>
</div>

<div class="nk-gap-4"></div>
