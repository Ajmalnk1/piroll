<?php
/**
 * Content end wrapper
 *
 * @package Piroll
 */

$type = piroll_post_type_is();
$container_type = piroll_get_theme_mod( $type . '_boxed', true );

$cont_class = 'container';
if ( $container_type != 'default' && $container_type != 'small' ) {
    $cont_class = 'container-fluid';
}
?>
    <?php if ( $container_type == 'small' ) : ?>
        </div>
    </div>
    <?php endif; ?>
</div>
