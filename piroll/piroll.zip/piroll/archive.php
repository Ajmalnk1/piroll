<?php
/**
 * The template for displaying archive pages.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Piroll
 */

get_header();
get_template_part( '/template-parts/header/archive' );

    get_template_part( '/template-parts/content-wrap-start' );

if ( piroll_get_theme_mod( 'archive_show_title', true ) && ! piroll_get_theme_mod( 'archive_header_show', true ) ) : ?>
            <div class="nk-gap-4"></div>
            <?php
            the_archive_title( '<h1 class="nk-title">', '</h1>' );
        endif;

        get_template_part( '/template-parts/content-archive-list' );

    get_template_part( '/template-parts/content-wrap-end' );

    $pagination = piroll_get_theme_mod( 'archive_pagination', true );
if ( $pagination ) {
    piroll_posts_navigation();

    if ( $pagination == 'infinite' || $pagination == 'load_more' ) {
        piroll_infinite_scroll_init();
    }
}
?>
<?php
get_footer();
