<?php
/**
 * Piroll Child functions and definitions
 *
 * @package Piroll Child
 */

add_action( 'wp_enqueue_scripts', 'piroll_child_enqueue_styles', 15 );
if ( ! function_exists( 'piroll_child_enqueue_styles' ) ) :
    /**
     * Enqueue child theme styles
     */
    function piroll_child_enqueue_styles() {
        wp_enqueue_style( 'piroll-child', get_stylesheet_directory_uri() . '/style.css' );
        wp_enqueue_script( 'piroll-child', get_stylesheet_directory_uri() . '/script.js', array( 'jquery' ) );
    }
endif;
